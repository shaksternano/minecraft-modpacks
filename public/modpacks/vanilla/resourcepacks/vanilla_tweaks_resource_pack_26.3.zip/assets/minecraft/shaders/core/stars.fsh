#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <vanilla_tweaks:twinkling_stars/stars_fsh.glsl>

out vec4 fragColor;

void main() {
    fragColor = twinklingStars_modifyColour(ColorModulator, GameTime);
}
